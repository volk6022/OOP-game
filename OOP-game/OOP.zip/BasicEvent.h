//#include "Player.h"
//#include "Cell.h"
//#include "Field.h"
//
//
//enum class EventSymbol : char {
//	Damage = '-',
//	Heal = '+',
//	Score = '*',
//	Teleport = '^',
//	Empty = '.',
//};
//
//
//class Event
//{
//public:
//	virtual void OnEvent() = 0;
//	virtual EventSymbol get_symbol() = 0;
//};