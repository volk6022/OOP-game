#pragma once
#include "Controller.h"
#include "Visualise.h"
#include <string>

struct ControlSymbol
{
	char symbol;
	Controlls action;
};

class Movement
{
private:
	Controller& contr;
	Visualise& vis;
	std::vector<ControlSymbol> symbols;

public:
	Movement(std::string path, Controller& contr, Visualise& vis);

	void readControls(std::string path);

	int action();
};

