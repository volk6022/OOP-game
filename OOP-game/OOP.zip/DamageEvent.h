#include "EventSystem.h"

#define def_damage 10
class DamageEvent : virtual public Event
{
private:
	EventSymbol symbol;
	Player* player;
	int damage;
public:
	DamageEvent(Player* player, int damage = def_damage);

	void OnEvent() override;

	EventSymbol get_symbol() override;
};
