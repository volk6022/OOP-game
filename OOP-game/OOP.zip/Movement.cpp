#include "Movement.h"

#include <fstream>
#include <exception>
#include <iostream>
#include <vector>
#include <conio.h>

#define def_up 'w'
#define def_down 's'
#define def_right 'd'
#define def_left 'a'
#define def_quit 'q'
#define def_menu 'm'


Movement::Movement(std::string path, Controller& contr, Visualise& vis) : contr(contr), vis(vis) {
    readControls(path);
}

void Movement::readControls(std::string path) {
    std::vector<ControlSymbol> defs;
    defs.push_back({ def_up, Controlls::up });
    defs.push_back({ def_down, Controlls::down });
    defs.push_back({ def_right, Controlls::right });
    defs.push_back({ def_left, Controlls::left });
    defs.push_back({ def_left, Controlls::quit });
    defs.push_back({ def_left, Controlls::MENU });
    if (path.empty()) {
        symbols = defs;
        return;
    }
    std::ifstream in(path);
    std::string str;
    for (int i = 0; i < static_cast<int>(Controlls::END); i++) {
        symbols.push_back({ '~', Controlls::up});
    }
    int j = 0;
    while (std::getline(in, str)) {
        if (str == "up\n") {
            symbols[static_cast<int>(Controlls::up)] =
            { std::getline(in, str) ? str[0] : def_up, Controlls::up };
            ++j;
        }
        else if (str == "down\n") {
            symbols[static_cast<int>(Controlls::down)] =
            { std::getline(in, str) ? str[0] : def_down, Controlls::down };
            ++j;
        }
        else if (str == "left\n") {
            symbols[static_cast<int>(Controlls::left)] =
            { std::getline(in, str) ? str[0] : def_left, Controlls::left };
            ++j;
        }
        else if (str == "right\n") {
            symbols[static_cast<int>(Controlls::right)] =
            { std::getline(in, str) ? str[0] : def_right, Controlls::right };
            ++j;
        }
        else if (str == "menu\n") {
            symbols[static_cast<int>(Controlls::right)] =
            { std::getline(in, str) ? str[0] : def_menu, Controlls::MENU };
            ++j;
        }
        else if (str == "quit\n") {
            symbols[static_cast<int>(Controlls::right)] =
            { std::getline(in, str) ? str[0] : def_quit, Controlls::quit };
            ++j;
        }
    }
    if (j < static_cast<int>(Controlls::END)) {
        for (int i = 0; i < static_cast<int>(Controlls::END); i++) {
            if(symbols[i].symbol == '~')
                symbols[i] = defs[i];
        }
    }
    in.close();
}

int Movement::action() {
    vis.printField();
    char act = _getch();
    for (int i = 0; i < symbols.size(); i++) {
        if (symbols[i].symbol == act) {
            contr.MovePlayer(symbols[i].action);
            return contr.EndGame();
        }
    }
    return contr.EndGame();
}


