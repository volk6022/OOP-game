#pragma once
#include "Generator.h"
#include "Movement.h"
#include "Visualise.h"


class Game
{
private:
	Generator* generator;
	Movement* movement;
	Visualise* visualise;

	void clear();
public:
	Game(bool start = false);
	
	void startGame();

	void menu();
};

