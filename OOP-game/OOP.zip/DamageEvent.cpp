#include "DamageEvent.h"

DamageEvent::DamageEvent(Player* player, int damage) :
	player(player), damage(damage), symbol(EventSymbol::Damage) {}

void DamageEvent::OnEvent() {
	if (player == nullptr) return;
	player->set_charact(Characts::HEALTH, player->get_charact(Characts::HEALTH).value - damage);
	damage = 0;
	symbol = EventSymbol::Empty;
}

EventSymbol DamageEvent::get_symbol() {
	return symbol;
}
