#include "EventSystem.h"

class TeleportEvent : virtual public Event
{
private:
	EventSymbol symbol;
	Player* player;
	Pos teleport;
public:
	TeleportEvent(Player* player, Pos teleport = def_pos);

	void OnEvent() override;

	EventSymbol get_symbol() override;
};