#pragma once
#include "Field.h"
#include "Player.h"


class Visualise
{
private:
	Field& field;
	Player& player;

public:
	Visualise(Field& field, Player&);

	void printField();
};

