#pragma once
#include "Player.h"
#include "Field.h"
#include "EventSystem.h"

#define go2menu 10
#define gemeOver 1


enum class Controlls {up=0, down, right, left, quit, MENU, END};


class Controller
{
private:
	Player& player;
	Field& field;
	int CheckEndGame;
	bool win;
	int steps;
	void SetEndGame();
public:
	Controller(Player &player, Field &field);

	void MovePlayer(Controlls direction);

	//void print();

	~Controller() {}

	void CallEvent(Pos position);

	int EndGame();

	bool get_win();
};