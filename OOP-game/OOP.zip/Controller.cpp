#include "Controller.h"

#define def_steps 0
#define def_EndGame false
#define def_GameContinue -1
#define def_win false
#define go2menu 2

#include <iostream>


Controller::Controller(Player& player, Field& field)
	: player(player), field(field), steps(def_steps), CheckEndGame(def_EndGame), win(def_win)
{
	CheckEndGame = 0;
	player.set_position(field.get_start());
}


void Controller::MovePlayer(Controlls direction)
{
	Pos position = player.get_position();
	++steps;
	player.set_charact(Characts::HEALTH, player.get_charact(Characts::HEALTH).value - 1);
	if ((position.x < 0) || (position.y < 0) || (position.x >= field.get_width()) || (position.y >= field.get_height()))
		SetEndGame();
	switch (direction)
	{
	case Controlls::down:
		if ((position.y + 1 >= field.get_height()) ||(!field.get_movable(position.x, position.y + 1))) return;
		position.y += 1;
		break;
	case Controlls::up:
		if ((0 > position.y - 1) || (!field.get_movable(position.x, position.y - 1))) return;
		position.y -= 1;
		break;
	case Controlls::left:
		if ((0 > position.x - 1) || (!field.get_movable(position.x - 1, position.y))) return;
		position.x -= 1;
		break;
	case Controlls::right:
		if ((field.get_width() <= position.x + 1) || (!field.get_movable(position.x + 1, position.y))) return;
		position.x += 1;
		break;
	case Controlls::quit:
		SetEndGame();
		exit(0);
	case Controlls::MENU:
		CheckEndGame = go2menu;
		return;
	}

	player.set_position(position);

	CallEvent(position);

	position = player.get_position();

	if ((position.x == field.get_stop().x) && (position.y == field.get_stop().y)) {
		win = true;
		this->SetEndGame();
	}
	if (player.get_charact(Characts::HEALTH).value <= 0)
		this->SetEndGame();
}


int Controller::EndGame()
{
	return CheckEndGame;
}


void Controller::CallEvent(Pos position)
{
	if (field.getCellEvent(position.x, position.y) != nullptr)
		field.getCellEvent(position.x, position.y)->OnEvent();
}


void Controller::SetEndGame()
{
	CheckEndGame = gemeOver;
}

bool Controller::get_win() {
	return win;
}
