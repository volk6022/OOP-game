#include "Visualise.h"
#include "EventSystem.h"

#include <iostream>

#define field_start '@'
#define field_stop '0'
#define not_movable '#'
#define movable '.'


Visualise::Visualise(Field & field, Player& player) : field(field), player(player) {}

void Visualise::printField() {
    system("cls");
    Pos p = player.get_position();
    for (int i = 0; i < field.get_height(); i++)
    {
        for (int j = 0; j < field.get_width(); j++) {
            if ((p.y == i) && (p.x == j)) {
                std::cout << '@' << ' ';
                continue;
            }
            if ((j == field.get_stop().x) && (i == field.get_stop().y)) {
                std::cout << '0' << ' ';
            }
            else if (field.get_movable(j, i)) {
                Event* e = field.getCellEvent(j, i);
                if (e == nullptr)
                    std::cout << char(EventSymbol::Empty) << ' ';
                else
                    std::cout << char(e->get_symbol()) << ' ';
            }
            else {
                std::cout << char(not_movable) << ' ';
            }
        }
        std::cout << '\n';
    }
    std::cout << "\nhealth:" << player.get_charact(Characts::HEALTH).value
        << "\nscore:" << player.get_charact(Characts::SCORE).value
        << "\nposition:" << player.get_position().x << ' ' << player.get_position().y << '\n';
}
