#include "EventSystem.h"

#define def_heal 10
class HealEvent : virtual public Event
{
private:
	EventSymbol symbol;
	Player* player;
	int heal;
public:
	HealEvent(Player* player, int heal = def_heal);

	void OnEvent() override;

	EventSymbol get_symbol() override;
};

