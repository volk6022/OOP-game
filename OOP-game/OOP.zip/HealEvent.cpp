#include "HealEvent.h"


HealEvent::HealEvent(Player* player, int heal) :
	player(player), heal(heal), symbol(EventSymbol::Heal) {}

void HealEvent::OnEvent() {
	if (player == nullptr) return;
	player->set_charact(Characts::HEALTH, player->get_charact(Characts::HEALTH).value + heal);
	heal = 0;
	symbol = EventSymbol::Empty;
}

EventSymbol HealEvent::get_symbol() {
	return symbol;
}
