
// this is enum for all available characteristics of player (or any other creation)
// this enum means the START and the END is needed for interactive initialisatio

//enum class Characts : int8_t
//{
//	START = 0,
//
//	HEALTH,
//	SCORE,
//	WEIGHT,
//
//	END,
//};
//
//
//#define def_value_type float
//
//
//struct Charact {
//	Characts type;
//	def_value_type value;
//	Charact(Characts type, def_value_type value) :
//		type(type), value(value) {}
//};